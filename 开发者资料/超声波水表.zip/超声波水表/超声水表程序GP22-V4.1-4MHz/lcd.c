#include "msp430x54x.h"
#include "functions.h"
#include "params.h"
#include "lcd.h"
#include "rtc.h"

const unsigned char graphic_battery0_icon[]=
{0x00,0x3C,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��0��16-8.BMP*/

const unsigned char graphic_battery1_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��1��16-8.BMP*/

const unsigned char graphic_battery2_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��2��16-8.BMP*/

const unsigned char graphic_battery3_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��3��16-8.BMP*/

const unsigned char graphic_battery4_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��4��16-8.BMP*/

const unsigned char graphic_battery5_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x3C,0x3C,0x00};/*���ͼ��5��16-8.BMP*/

const unsigned char graphic_magnetic_icon[]=
{0x00,0x3C,0x72,0xF9,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE7,0x00};/*�Ÿ�����ʾͼ��16-8.BMP*/

const unsigned char graphic_chinesejie_icon[]=
{0xFF,0x89,0xF5,0x13,0x08,0xF4,0x02,0x01,0x02,0xF4,0x08,0x10,0x0F,0x00,0x00,0x08,
0x06,0x01,0x00,0x00,0x00,0x0F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00};/*���Ľ�ͼ��12-24.BMP*/

const unsigned char graphic_chineseti_icon[]=
{0xC4,0x34,0xFF,0x14,0x10,0x75,0xD6,0xFC,0x56,0x55,0x5C,0xC0,0x00,0x00,0x0F,0x00,
0x02,0x01,0x00,0x0F,0x00,0x02,0x04,0x07,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00};/*������ͼ��12-24.BMP*/

const unsigned char graphic_jieti1_icon[]=
{0x00,0x04,0x04,0xFE,0x00,0x00,0x08,0x08,0x08,0x0F,0x08,0x08,0x00,0x00,0x00,0x00,
0x00,0x00};/*����1ͼ��6-24.BMP*/

const unsigned char graphic_jieti2_icon[]=
{0x0C,0x02,0x82,0x42,0x22,0x1C,0x0E,0x09,0x08,0x08,0x08,0x0C,0x00,0x00,0x00,0x00,
0x00,0x00};/*����2ͼ��6-24.BMP*/

const unsigned char graphic_jieti3_icon[]=
{0x0C,0x02,0x22,0x22,0x52,0x8C,0x06,0x08,0x08,0x08,0x04,0x03,0x00,0x00,0x00,0x00,
0x00,0x00};/*����3ͼ��6-24.BMP*/

const unsigned char graphic_chinesedang_icon[]=
{0xC4,0x34,0xFF,0x14,0x00,0x52,0x5C,0x50,0x5F,0x58,0x54,0xF2,0x00,0x00,0x0F,0x00,
0x02,0x02,0x02,0x02,0x02,0x02,0x02,0x07,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00};/*���ĵ�ͼ��12-24.BMP*/

const unsigned char graphic_chineselei_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0xF0,0x50,0x50,0xF0,0x50,0x50,0x50,0xF0,0x00,0x00,0x00,0x00,0x00,0x80,0xD1,
0x15,0x57,0x9D,0x75,0x1B,0x51,0xB1,0x00,0x00,0x00};/*������ͼ��14-24.BMP*/

const unsigned char graphic_chineseji_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0xA0,0xA0,0xF0,0x90,0x90,0x00,0xE0,0x20,0x20,0x20,0x20,0xE0,0x00,0x00,0x00,
0x00,0x18,0x06,0xFF,0x02,0x0C,0x40,0x33,0x1A,0x02,0x02,0x0A,0x33,0x60,0x00,0x00};/*���Ļ�ͼ��16-24.BMP*/

const unsigned char graphic_chineseliang_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,
0x80,0xF0,0xF0,0xF0,0xF0,0xF0,0xF0,0xF0,0xF0,0x80,0x80,0x00,0x00,0x00,0x80,0xAF,
0xAA,0xAA,0xFF,0xAA,0xAA,0xAA,0xAF,0x80,0x00,0x00};/*������ͼ��14-24.BMP*/

const unsigned char graphic_monthsubmenu_icon[]=
{0x00,0xFE,0x42,0xC2,0xC2,0x02,0x02,0x02,0xC2,0xC2,0x6A,0x04,0x28,0x10,0xE0,0x00,
0x00,0xFF,0xA0,0xBF,0x81,0x86,0x98,0x86,0x81,0xBF,0xA0,0x80,0x80,0x80,0xFF,0x00};;/*�����Ӳ˵�ͼ��16-16.BMP*/

const unsigned char graphic_laddersubmenu_icon[]=
{0x04,0xFE,0x04,0x10,0x10,0x10,0xF0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x7F,0x40,0x40,0x40,0x40,0x41,0x41,0x41,0x5F,0x50,0x50,0x50,0x40,0xE0,0x40};/*����ˮ���Ӳ˵�ͼ��16-16.BMP*/

const unsigned char graphic_alarmsubmenu_icon[]=
{0x00,0x00,0x00,0x00,0xC0,0xF8,0xFE,0x07,0xFE,0xF8,0xC0,0x00,0x00,0x00,0x00,0x00,
0x80,0xC0,0xF0,0xFE,0xFF,0xFF,0xFF,0xCC,0xFF,0xFF,0xFF,0xFE,0xF0,0xC0,0x80,0x00};/*���������Ӳ˵�ͼ��16-16.BMP*/

const unsigned char graphic_daysubmenu_icon[]=
{0x00,0xFE,0x22,0xE2,0x22,0x22,0x22,0x22,0x42,0x82,0x2A,0x04,0x28,0x10,0xE0,0x00,
0x00,0xFF,0xA0,0xBF,0xA0,0xA0,0xA0,0xA0,0x90,0x8F,0x80,0x80,0x80,0x80,0xFF,0x00};/*���ۻ��������Ӳ˵�ͼ��16-16.BMP*/

const unsigned char graphic_irsubmenu_icon[]=
{0x00,0x00,0x00,0x20,0x40,0x80,0x00,0x00,0xF0,0x00,0x00,0x80,0x40,0x20,0x00,0x00,
0x00,0x20,0x20,0x20,0x20,0x30,0x38,0x3C,0x3C,0x3C,0x38,0x30,0x20,0x20,0x20,0x20};/*����ͨѶ�Ӳ˵�ͼ��16-16.BMP*/

const unsigned char graphic_datenumber0_icon[]=
{0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,0x00,0x0F,0x10,0x20,0x20,0x10,0x0F,0x00};/*��������0ͼ��8-16.BMP*/

const unsigned char graphic_datenumber1_icon[]=
{0x00,0x10,0x10,0xF8,0x00,0x00,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00};/*��������1ͼ��8-16.BMP*/

const unsigned char graphic_datenumber2_icon[]=
{0x00,0x70,0x08,0x08,0x08,0x88,0x70,0x00,0x00,0x30,0x28,0x24,0x22,0x21,0x30,0x00};/*��������2ͼ��8-16.BMP*/

const unsigned char graphic_datenumber3_icon[]=
{0x00,0x30,0x08,0x88,0x88,0x48,0x30,0x00,0x00,0x18,0x20,0x20,0x20,0x11,0x0E,0x00};/*��������3ͼ��8-16.BMP*/

const unsigned char graphic_datenumber4_icon[]=
{0x00,0x00,0xC0,0x20,0x10,0xF8,0x00,0x00,0x00,0x07,0x04,0x24,0x24,0x3F,0x24,0x00};/*��������4ͼ��8-16.BMP*/

const unsigned char graphic_datenumber5_icon[]=
{0x00,0xF8,0x08,0x88,0x88,0x08,0x08,0x00,0x00,0x19,0x21,0x20,0x20,0x11,0x0E,0x00};/*��������5ͼ��8-16.BMP*/

const unsigned char graphic_datenumber6_icon[]=
{0x00,0xE0,0x10,0x88,0x88,0x18,0x00,0x00,0x00,0x0F,0x11,0x20,0x20,0x11,0x0E,0x00};/*��������6ͼ��8-16.BMP*/

const unsigned char graphic_datenumber7_icon[]=
{0x00,0x38,0x08,0x08,0xC8,0x38,0x08,0x00,0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00};/*��������7ͼ��8-16.BMP*/

const unsigned char graphic_datenumber8_icon[]=
{0x00,0x70,0x88,0x08,0x08,0x88,0x70,0x00,0x00,0x1C,0x22,0x21,0x21,0x22,0x1C,0x00};/*��������8ͼ��8-16.BMP*/

const unsigned char graphic_datenumber9_icon[]=
{0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,0x00,0x00,0x31,0x22,0x22,0x11,0x0F,0x00};/*��������9ͼ��8-16.BMP*/

const unsigned char graphic_datenumberinterval_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x01,0x01,0x01,0x01,0x01,0x01};/*�������ּ���ܷ�ͼ��8-16.BMP*/

const unsigned char graphic_timenumberinterval_icon[]=
{0x00,0x00,0x00,0xC0,0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00};/*ʱ�����ּ��ð�ŷ�ͼ��8-16.BMP*/

const unsigned char graphic_datanumberdot_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00,0x00,0x00};/*"."С����*/

const unsigned char graphic_up_icon[]=
{0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0xFF,0x7C,0x38,0x10};/*˳��ͼ��8-16.BMP*/

const unsigned char graphic_down_icon[]=
{0x10,0x38,0x7C,0xFF,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18};/*����ͼ��16-16.BMP*/

const unsigned char graphic_cumnmuber0_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0xFF,0xFF,0x00,
0x00,0x00,0x00,0x00,0x00,0xFF,0xFF,0x00,0x00,0x07,0x0F,0x10,0x30,0x30,0x30,0x30,
0x10,0x0F,0x07,0x00};/*�ۻ�������0ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber0rightdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0xFF,0xFF,0x00,
0x00,0x00,0x00,0x00,0x00,0xFF,0xFF,0x00,0x00,0x07,0x0F,0x10,0x30,0x30,0x30,0x30,
0x10,0x0F,0x07,0x30};/*�ۻ�������0�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber0leftdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0xFF,0xFF,0x00,
0x00,0x00,0x00,0x00,0x00,0xFF,0xFF,0x00,0x30,0x07,0x0F,0x10,0x30,0x30,0x30,0x30,
0x10,0x0F,0x07,0x00};/*�ۻ�������0���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber1_icon[]=
{0x00,0x00,0x00,0x08,0x0C,0xFE,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x30,0x3F,0x3F,0x30,
0x30,0x30,0x00,0x00};/*�ۻ�������1ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber1rightdot_icon[]=
{0x00,0x00,0x00,0x08,0x0C,0xFE,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x30,0x3F,0x3F,0x30,
0x30,0x30,0x00,0x30};/*�ۻ�������1�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber1leftdot_icon[]=
{0x00,0x00,0x00,0x08,0x0C,0xFE,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x30,0x00,0x30,0x30,0x30,0x3F,0x3F,0x30,
0x30,0x30,0x00,0x00};/*�ۻ�������1���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber2_icon[]=
{0x00,0x38,0x7C,0x02,0x03,0x03,0x03,0x03,0x82,0xFC,0xF8,0x00,0x00,0xC0,0xE0,0x70,
0x38,0x1C,0x0E,0x07,0x03,0x01,0x00,0x00,0x00,0x07,0x0F,0x10,0x30,0x30,0x30,0x30,
0x10,0x0C,0x04,0x00};/*�ۻ�������2ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber2rightdot_icon[]=
{0x00,0x38,0x7C,0x02,0x03,0x03,0x03,0x03,0x82,0xFC,0xF8,0x00,0x00,0xC0,0xE0,0x70,
0x38,0x1C,0x0E,0x07,0x03,0x01,0x00,0x00,0x00,0x07,0x0F,0x10,0x30,0x30,0x30,0x30,
0x10,0x0C,0x04,0x30};/*�ۻ�������2�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber2leftdot_icon[]=
{0x00,0x38,0x7C,0x02,0x03,0x03,0x03,0x03,0x82,0xFC,0xF8,0x00,0x00,0xC0,0xE0,0x70,
0x38,0x1C,0x0E,0x07,0x03,0x01,0x00,0x00,0x30,0x07,0x0F,0x10,0x30,0x30,0x30,0x30,
0x10,0x0C,0x04,0x00};/*�ۻ�������2���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber3_icon[]=
{0x00,0x38,0x3C,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0x00,0x00,0x06,
0x06,0x06,0x06,0x0E,0x1B,0xF1,0xE0,0x00,0x00,0x06,0x0E,0x10,0x30,0x30,0x30,0x30,
0x10,0x0F,0x07,0x00};/*�ۻ�������3ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber3rightdot_icon[]=
{0x00,0x38,0x3C,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0x00,0x00,0x06,
0x06,0x06,0x06,0x0E,0x1B,0xF1,0xE0,0x00,0x00,0x06,0x0E,0x10,0x30,0x30,0x30,0x30,
0x10,0x0F,0x07,0x30};/*�ۻ�������3�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber3leftdot_icon[]=
{0x00,0x38,0x3C,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0x00,0x00,0x06,
0x06,0x06,0x06,0x0E,0x1B,0xF1,0xE0,0x00,0x30,0x06,0x0E,0x10,0x30,0x30,0x30,0x30,
0x10,0x0F,0x07,0x00};/*�ۻ�������3���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber4_icon[]=
{0x00,0x00,0x00,0x80,0xC0,0xE0,0x70,0xFC,0xFF,0x00,0x00,0x00,0x00,0x7E,0x7F,0x63,
0x61,0x60,0x60,0xFF,0xFF,0x60,0x60,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x3F,
0x3F,0x30,0x00,0x00};/*�ۻ�������4ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber4rightdot_icon[]=
{0x00,0x00,0x00,0x80,0xC0,0xE0,0x70,0xFC,0xFF,0x00,0x00,0x00,0x00,0x7E,0x7F,0x63,
0x61,0x60,0x60,0xFF,0xFF,0x60,0x60,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x3F,
0x3F,0x30,0x00,0x30};/*�ۻ�������4�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber4leftdot_icon[]=
{0x00,0x00,0x00,0x80,0xC0,0xE0,0x70,0xFC,0xFF,0x00,0x00,0x00,0x00,0x7E,0x7F,0x63,
0x61,0x60,0x60,0xFF,0xFF,0x60,0x60,0x00,0x30,0x00,0x00,0x00,0x00,0x30,0x30,0x3F,
0x3F,0x30,0x00,0x00};/*�ۻ�������4���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber5_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x03,0x02,0x00,0x00,0x00,0x03,0x07,0x0C,
0x06,0x03,0x03,0x03,0x06,0xFC,0xF8,0x00,0x00,0x04,0x0E,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x00};/*�ۻ�������5ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber5rightdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x03,0x02,0x00,0x00,0x00,0x03,0x07,0x0C,
0x06,0x03,0x03,0x03,0x06,0xFC,0xF8,0x00,0x00,0x04,0x0E,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x30};/*�ۻ�������5�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber5leftdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x03,0x02,0x00,0x00,0x00,0x03,0x07,0x0C,
0x06,0x03,0x03,0x03,0x06,0xFC,0xF8,0x00,0x30,0x04,0x0E,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x00};/*�ۻ�������5���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber6_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0x1C,0x18,0x00,0x00,0xFF,0xFF,0x18,
0x0C,0x06,0x06,0x06,0x0C,0xF8,0xF0,0x00,0x00,0x07,0x0F,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x00};/*�ۻ�������6ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber6rightdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0x1C,0x18,0x00,0x00,0xFF,0xFF,0x18,
0x0C,0x06,0x06,0x06,0x0C,0xF8,0xF0,0x00,0x00,0x07,0x0F,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x30};/*�ۻ�������6�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber6leftdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0x1C,0x18,0x00,0x00,0xFF,0xFF,0x18,
0x0C,0x06,0x06,0x06,0x0C,0xF8,0xF0,0x00,0x30,0x07,0x0F,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x00};/*�ۻ�������6���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber7_icon[]=
{0x00,0x1C,0x1E,0x03,0x03,0x03,0x03,0xC3,0xC3,0x7F,0x7F,0x03,0x00,0x00,0x00,0x00,
0x80,0xF0,0x7E,0x0F,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0x3F,0x00,0x00,
0x00,0x00,0x00,0x00};/*�ۻ�������7ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber7rightdot_icon[]=
{0x00,0x1C,0x1E,0x03,0x03,0x03,0x03,0xC3,0xC3,0x7F,0x7F,0x03,0x00,0x00,0x00,0x00,
0x80,0xF0,0x7E,0x0F,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0x3F,0x00,0x00,
0x00,0x00,0x00,0x30};/*�ۻ�������7�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber7leftdot_icon[]=
{0x00,0x1C,0x1E,0x03,0x03,0x03,0x03,0xC3,0xC3,0x7F,0x7F,0x03,0x00,0x00,0x00,0x00,
0x80,0xF0,0x7E,0x0F,0x01,0x00,0x00,0x00,0x30,0x00,0x00,0x00,0x3F,0x3F,0x00,0x00,
0x00,0x00,0x00,0x00};/*�ۻ�������7���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber8_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0xE0,0xF1,0x1B,
0x0E,0x0C,0x0C,0x0E,0x1B,0xF1,0xE0,0x00,0x00,0x07,0x0F,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x00};/*�ۻ�������8ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber8rightdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0xE0,0xF1,0x1B,
0x0E,0x0C,0x0C,0x0E,0x1B,0xF1,0xE0,0x00,0x00,0x07,0x0F,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x30};/*�ۻ�������8�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber8leftdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0xE0,0xF1,0x1B,
0x0E,0x0C,0x0C,0x0E,0x1B,0xF1,0xE0,0x00,0x30,0x07,0x0F,0x18,0x30,0x30,0x30,0x30,
0x18,0x0F,0x07,0x00};/*�ۻ�������8���ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber9_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0x01,0x03,0x06,
0x0C,0x0C,0x0C,0x04,0x02,0xFF,0xFF,0x00,0x00,0x00,0x06,0x0E,0x10,0x30,0x30,0x30,
0x10,0x0F,0x07,0x00};/*�ۻ�������9ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber9rightdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0x01,0x03,0x06,
0x0C,0x0C,0x0C,0x04,0x02,0xFF,0xFF,0x00,0x00,0x00,0x06,0x0E,0x10,0x30,0x30,0x30,
0x10,0x0F,0x07,0x30};/*�ۻ�������9�ҵ�ͼ��12-24.BMP*/

const unsigned char graphic_cumnmuber9leftdot_icon[]=
{0x00,0xF8,0xFC,0x02,0x03,0x03,0x03,0x03,0x02,0xFC,0xF8,0x00,0x00,0x01,0x03,0x06,
0x0C,0x0C,0x0C,0x04,0x02,0xFF,0xFF,0x00,0x30,0x00,0x06,0x0E,0x10,0x30,0x30,0x30,
0x10,0x0F,0x07,0x00};/*�ۻ�������9���ͼ��12-24.BMP*/

const unsigned char graphic_cumunit_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x40,0xC0,0x40,
0x40,0xC0,0x40,0x40,0x80,0x20,0x90,0x60,0x00,0x20,0x3F,0x20,0x00,0x3F,0x20,0x00,
0x3F,0x02,0x04,0x03};/*�ۻ�����λͼ��12-24.BMP  m3 */ 

const unsigned char graphic_m_icon[]=
{0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x20,0x3F,0x20,0x00,0x3F,0x20,0x00,0x3F};/*"m",0*/
  
const unsigned char graphic_L_icon[]=
{0x08,0xF8,0x08,0x00,0x00,0x00,0x00,0x00,0x20,0x3F,0x20,0x20,0x20,0x20,0x30,0x00};/*"l",0*/ 

const unsigned char graphic_mL_icon[]=
{0x00,0x00,0x00,0x00,0x00,0xF0,0x00,0x00,0x3F,0x02,0x3E,0x02,0x3F,0x7F,0x40,0x40};/*"ml",0*/ 

const unsigned char graphic_chineseliu_icon[]=
{0x10,0x60,0x01,0x86,0x60,0x04,0x44,0x64,0x55,0x4E,0x44,0x64,0xC4,0x04,0x04,0x00,
0x04,0x04,0xFC,0x03,0x40,0x30,0x0F,0x00,0x00,0x7F,0x00,0x3F,0x40,0x40,0x70,0x00};/*"��",0*/

const unsigned char graphic_chinesesu_icon[]=
{0x40,0x42,0xCC,0x00,0x04,0xE4,0x24,0x24,0xFF,0x24,0x24,0x24,0xE4,0x04,0x00,0x00,
0x40,0x20,0x1F,0x20,0x48,0x49,0x45,0x43,0x7F,0x41,0x43,0x45,0x4D,0x40,0x40,0x00};/*"��",0*/

const unsigned char graphic_o_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x0E,0x0A,0x0E,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};/*"o",0*/

const unsigned char graphic_C_icon[]=
{0xC0,0x30,0x08,0x08,0x08,0x08,0x38,0x00,0x07,0x18,0x20,0x20,0x20,0x10,0x08,0x00};/*"C",0*/

const unsigned char graphic_chinesewen_icon[]=
{0x10,0x21,0x86,0x70,0x00,0x7E,0x4A,0x4A,0x4A,0x4A,0x4A,0x7E,0x00,0x00,0x00,0x00,
0x02,0xFE,0x01,0x40,0x7F,0x41,0x41,0x7F,0x41,0x41,0x7F,0x41,0x41,0x7F,0x40,0x00};/*"��",0*/

const unsigned char graphic_chinesedu_icon[]=
{0x00,0x00,0xFC,0x04,0x24,0x24,0xFC,0xA5,0xA6,0xA4,0xFC,0x24,0x24,0x24,0x04,0x00,
0x80,0x60,0x1F,0x80,0x80,0x42,0x46,0x2A,0x12,0x12,0x2A,0x26,0x42,0xC0,0x40,0x00};/*"��",0*/

const unsigned char graphic_T_icon[]=
{0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00};/*"T",0*/

const unsigned char graphic_F_icon[]=
{0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x00,0x03,0x00,0x00,0x00};/*"F",0*/

const unsigned char graphic_U_icon[]=
{0x08,0xF8,0x08,0x00,0x00,0x08,0xF8,0x08,0x00,0x1F,0x20,0x20,0x20,0x20,0x1F,0x00};/*"U",0*/

const unsigned char graphic_D_icon[]=
{0x08,0xF8,0x08,0x08,0x08,0x10,0xE0,0x00,0x20,0x3F,0x20,0x20,0x20,0x10,0x0F,0x00};/*"D",0*/

const unsigned char graphic_p_icon[]=
{0x80,0x80,0x00,0x80,0x80,0x00,0x00,0x00,0x80,0xFF,0xA1,0x20,0x20,0x11,0x0E,0x00};/*"p",0*/

const unsigned char graphic_s_icon[]=
{0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x33,0x24,0x24,0x24,0x24,0x19,0x00};/*"s",0*/

const unsigned char graphic_maohao_icon[]=
{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x36,0x36,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};/*"��",0*/

const unsigned char graphic_h_icon[]=
{0x00,0xC0,0x3C,0xFE,0x80,0x80,0x80,0x80,0x3C,0x07,0x00,0x3F,0x00,0x00,0x00,0x3F};

const unsigned char graphic_chinesehong_icon[]=
{0x20,0x30,0x2C,0xA3,0x60,0x18,0x00,0x08,0x08,0x08,0xF8,0x08,0x08,0x0C,0x08,0x00,
0x22,0x66,0x23,0x12,0x12,0x52,0x40,0x40,0x40,0x40,0x7F,0x40,0x40,0x60,0x40,0x00};/*"��",0*/

const unsigned char graphic_chinesewai_icon[]=
{0x80,0x40,0x20,0x58,0x87,0x04,0xC4,0x3C,0x00,0x00,0xFF,0x20,0x40,0x80,0x00,0x00,
0x40,0x20,0x10,0x08,0x05,0x03,0x00,0x00,0x00,0x00,0xFF,0x00,0x00,0x00,0x03,0x00};/*"��",0*/

const unsigned char graphic_d_icon[]=
{0x00,0x00,0x00,0x80,0x80,0x88,0xF8,0x00,0x00,0x0E,0x11,0x20,0x20,0x10,0x3F,0x20};/*"d",0*/

const unsigned char graphic_o1_icon[]=
{0x00,0x00,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x1F,0x20,0x20,0x20,0x20,0x1F,0x00};/*"o",0*/

const unsigned char graphic_t_icon[]=
{0x00,0x80,0x80,0xE0,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x1F,0x20,0x20,0x00,0x00};/*"t",0*/



//LCD��λ
void ResetLCD(void)
{
  LCD_RST0;
  delay_ms(20);
  LCD_RST1;
  delay_ms(20);
}

//LCDд����
void Write_LCD_COM(unsigned char COMDADA_4SPI)
{
  unsigned char bit8;
  LCD_A00;
  LCD_CS0;
  for(bit8 = 0; bit8 < 8; bit8++)
  {
    LCD_SCL0;
    if((COMDADA_4SPI & 0x80) == 0x80)
     LCD_SDA1;
    else		
     LCD_SDA0;
    LCD_SCL1;
    COMDADA_4SPI <<= 1;
  }
  LCD_CS1;
  LCD_A01;
  //delay_us(5);
}

//LCDд����
void Write_LCD_DATA(unsigned char DADA_4SPI)
{   
  unsigned char bit8;
  LCD_A01;
  LCD_CS0;				
  for(bit8 = 0; bit8 < 8; bit8++)
  {
    LCD_SCL0;
    if((DADA_4SPI & 0x80) == 0x80)
     LCD_SDA1;
    else
     LCD_SDA0;
    LCD_SCL1;
    DADA_4SPI <<= 1;
  }
  LCD_CS1;
  LCD_A01;
  //delay_us(5);
}

void Column_set(unsigned char column)
{
   Write_LCD_COM(0x10|(column>>4));
   Write_LCD_COM(0x00|(column&0x0f));
}

void Page_set(unsigned char page)
{
   Write_LCD_COM(0xb0+page);
}

//LCD����
void ClearLCD(unsigned char xx) //����
{               
  unsigned char i,j;
  for(i = 0; i < 8; i++)
  {
    //LCD_CS0;
    Page_set(i);
    Column_set(0);
    for(j = 0; j < 128 ; j++)
    {
      Write_LCD_DATA(xx);
    }
    //LCD_CS1;
   }
}


void Picture_display(unsigned char *ptr_pic)
{
    unsigned char page,column;
    for(page=0;page<(64/8);page++)        //page loop
    {
       Page_set(page);
       Column_set(0);
       for(column=0;column<128;column++)	//column loop
       {
          Write_LCD_DATA(*ptr_pic++);
       }
    }
    delay_ms(10);
}

//LCD��ʼ��
void InitLCD(void)
{
  P4DIR |= BIT2;                //��Ϊ�������LCD_SDA��
  P4DIR |= BIT0;                //��Ϊ�������LCD_SCK��
  P4DIR |= BIT4;                //��Ϊ�������LCD_A0��
  P4DIR |= BIT5;                //��Ϊ�������LCD_RESET��
  P4DIR |= BIT3;                //��Ϊ�������LCD_CS��
  //P4DIR |= BIT0;                //��Ϊ�������LCD_BackLight��
  //P3DIR |= BIT7; 
  //P4DIR |= BIT0;                //��Ϊ�������LCD_power��
  
  
  LCD_CS0;
  //LCD_BackLight0;
  //LCD_Power0;
  
  //LCD_BackLight11;
  
  ResetLCD();
  delay_ms(10);
  /*
  Write_LCD_COM(0xE2);//�Ĵ�����λ
  
  Write_LCD_COM(0xAF);
  Write_LCD_COM(0x2F);
  Write_LCD_COM(0x25);
  
  Write_LCD_COM(0x81);
  Write_LCD_COM(0x1f);
  Write_LCD_COM(0xA0);
  
  Write_LCD_COM(0xC8);
  
  Write_LCD_COM(0xA6);
  Write_LCD_COM(0xA4);
  
  Write_LCD_COM(0xF8);
  Write_LCD_COM(0x00);
   */
   ///*
Write_LCD_COM(0xae);	//--turn off oled panel

Write_LCD_COM(0x00);	//--set low column address
Write_LCD_COM(0x10);	//--set high column address

Write_LCD_COM(0x40);	//--set start line address

Write_LCD_COM(0xb0);	//--set page address

Write_LCD_COM(0x81);	//--set contrast control register
Write_LCD_COM(0xff);

Write_LCD_COM(0xa1);	//--set segment re-map 127 to 0   a0:0 to seg127
Write_LCD_COM(0xa6);	//--set normal display

Write_LCD_COM(0xc8);	//--set com(N-1)to com0  c0:com0 to com(N-1)

Write_LCD_COM(0xa8);	//--set multiples ratio(1to64)
Write_LCD_COM(0x3f);	//--1/64 duty

Write_LCD_COM(0xd3);	//--set display offset
Write_LCD_COM(0x00);	//--not offset

Write_LCD_COM(0xd5);	//--set display clock divide ratio/oscillator frequency
Write_LCD_COM(0x80);	//--set divide ratio

Write_LCD_COM(0xd9);	//--set pre-charge period
Write_LCD_COM(0xf1);

Write_LCD_COM(0xda);	//--set com pins hardware configuration
Write_LCD_COM(0x12);

Write_LCD_COM(0xdb);	//--set vcomh
Write_LCD_COM(0x40);

Write_LCD_COM(0x8d);	//--set chare pump enable/disable
Write_LCD_COM(0x14);	//--set(0x10) disable
//Write_LCD_COM(0x10);	//--set(0x10) disable
Write_LCD_COM(0xaf);	//--turn on oled panel
       //*/
   //LCD_CS1;
   
  //ClearLCD(0x00);

  //while(1)
     {
        //ClearLCD(0x00);
        //Picture_display(picture_tab);
        //delay_ms(5000);
        ClearLCD(0xFF);
        delay_ms(500);
        ClearLCD(0x00);
        delay_ms(500);
     }
  
}

//LCD��
void OpenLCD(void)
{
  InitLCD();
}

//LCD�ر�
void CloseLCD(void)
{
  LCD_CS1;
  //LCD_BackLight11;
  //LCD_Power1;
}

//���ͼ����ʾ
void Display_Battery_Icon(unsigned char battery_capacity)
{
  unsigned char i,j,adressd = 0;
  for(i = 0; i < 1; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    
    switch(battery_capacity)
    {
    case 0:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery0_icon[adressd]);
          adressd++;
        }
        break;
      } 
     case 1:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery1_icon[adressd]);
          adressd++;
        }
        break;
      }  
     case 2:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery2_icon[adressd]);
          adressd++;
        }
        break;
      }  
     case 3:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery3_icon[adressd]);
          adressd++;
        }
        break;
      }
     case 4:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery4_icon[adressd]);
          adressd++;
        }
        break;
      } 
     case 5:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery5_icon[adressd]);
          adressd++;
        }
        break;
      } 
    default: break;    
    }
    LCD_CS1;
  } 
  
}  

//�Ÿ���ͼ����ʾ
void Display_Magnetic_Icon(unsigned char flag)
{
  unsigned char i,j,adressd = 0;
  for(i = 0; i < 1; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    if(flag)
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(graphic_magnetic_icon[adressd]);
        adressd++;
      }
    }
    else
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(0x00);//����ű���ͼ��
      }
    }
    LCD_CS1;
  } 
  
  for(i = 0; i < 1; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 48; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
  
}

//���ۻ�����������ʾ
void Display_CumChinese_Icon(void)
{
  unsigned char i,j,adressd = 0;
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 14; j++)
    {
      Write_LCD_DATA(graphic_chineselei_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x0e);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_chineseji_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x0e);
    for(j = 0; j < 14; j++)
    {
      Write_LCD_DATA(graphic_chineseliang_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  } 
   
}

//�ۻ���С��������ʾ
void Display_LiuLiangDotChinese_Icon(void)
{
  unsigned char i,j,adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_d_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_o1_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }  
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_t_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x08);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_maohao_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }  
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_m_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_L_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
    
  } 
  
}

//������������ʾ
void Display_LiuSuChinese_Icon(void)
{
  unsigned char i,j,adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_chineseliu_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_chinesesu_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_L_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_h_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  } 
  
}


//�¶���������ʾ
void Display_WenDuChinese_Icon(void)
{
  unsigned char i,j,adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_chinesewen_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_chinesedu_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_o_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_C_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  } 
  
}


//����ʱ����ʾ
void Display_TimeOfFlight_Icon( unsigned char flag )
{
  unsigned char i,j,adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_T_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x08);
    if(DISP_STAT_TIMEF==flag) // ����ʱ���
    {
      for(j = 0; j < 8; j++)
      {
        Write_LCD_DATA(graphic_F_icon[adressd]);
        adressd++;
      }
    }
    else if(DISP_STAT_TIMEU==flag) // ���η���ʱ��
    {
      for(j = 0; j < 8; j++)
      {
        Write_LCD_DATA(graphic_U_icon[adressd]);
        adressd++;
      }
    }    
    else if(DISP_STAT_TIMED==flag) // ���η���ʱ��
    {
      for(j = 0; j < 8; j++)
      {
        Write_LCD_DATA(graphic_D_icon[adressd]);
        adressd++;
      }
    } 
    LCD_CS1;
  }
  
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_maohao_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }  
  
  /*adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_p_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_s_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  } */
  
}

//������������ʾ
void Display_HongWaiChinese_Icon(void)
{
  unsigned char i,j,adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_chinesehong_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(graphic_chinesewai_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }  
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }   
    for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }  
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }   
}

void Display_Switch_DateNumber(unsigned char num, unsigned char hang)
{
  unsigned char k = 0;
  switch(num)
  {
  case 0:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber0_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber0_icon[k + 8]);       
      }
      break;
    }
  case 1:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber1_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber1_icon[k + 8]);       
      }
      break;
    }
  case 2:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber2_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber2_icon[k + 8]);      
      }
      break;
    }
  case 3:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber3_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber3_icon[k + 8]);       
      }
      break;
    }
  case 4:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber4_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber4_icon[k + 8]);       
      }
      break;
    }
  case 5:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber5_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber5_icon[k + 8]);     
      }
      break;
    }
  case 6:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber6_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber6_icon[k + 8]);      
      }
      break;
    }
   case 7:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber7_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber7_icon[k + 8]);      
      }
      break;
    }
   case 8:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber8_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber8_icon[k + 8]);   
      }
      break;
    }
   case 9:
    {
      for(k = 0; k < 8; k++)
      {
        if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datenumber9_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datenumber9_icon[k + 8]);       
      }
      break;
    }
   case 10:
    {
      for(k = 0; k < 8; k++)
      {
       if( (hang == 4)||(hang == 6) )
          Write_LCD_DATA(graphic_datanumberdot_icon[k]);
        else if( (hang == 5)||(hang == 7) )
          Write_LCD_DATA(graphic_datanumberdot_icon[k + 8]);       
      }
      break;
    }    
   default: break;   
  }
}

//������ʾ
void Display_Date_Icon(unsigned char year, unsigned char month, unsigned char day, unsigned char hour, unsigned char minute)
{
  unsigned char i,j,adressd = 0;
  unsigned char temp1, temp2;
  /*for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumber2_icon[adressd]);
      adressd++;
    }
  }
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumber0_icon[adressd]);
      adressd++;
    }
  }
  //year
  temp1 = BCDtoDec(year);
  temp2 = temp1/10;//ʮλ
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }
  //-
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumberinterval_icon[adressd]);
      adressd++;
    }
  }
  //month
  temp1 = BCDtoDec(month);
  temp2 = temp1/10;//ʮλ
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  //-
  adressd = 0;
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumberinterval_icon[adressd]);
      adressd++;
    }
  }
  //day
  temp1 = BCDtoDec(day);
  temp2 = temp1/10;//ʮλ
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }*/
  
  
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumber2_icon[adressd]);
      adressd++;
    }
  }
  adressd = 0;
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumber0_icon[adressd]);
      adressd++;
    }
  }
  //year
  temp1 = BCDtoDec(year);
  temp2 = temp1/10;//ʮλ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  //-
  adressd = 0;
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumberinterval_icon[adressd]);
      adressd++;
    }
  }
  //month
  temp1 = BCDtoDec(month);
  temp2 = temp1/10;//ʮλ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }
  //-
  adressd = 0;
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_datenumberinterval_icon[adressd]);
      adressd++;
    }
  }
  //day
  temp1 = BCDtoDec(day);
  temp2 = temp1/10;//ʮλ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  //hour
  temp1 = BCDtoDec(hour);
  temp2 = temp1/10;//ʮλ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }
  //��
  adressd = 0;
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_timenumberinterval_icon[adressd]);
      adressd++;
    }
  }
  //minute
  temp1 = BCDtoDec(minute);
  temp2 = temp1/10;//ʮλ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    Display_Switch_DateNumber(temp2,i);
  }
  temp2 = temp1%10;//��λ
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(temp2,i);
  }
  
}

//������Ϣ��ʾ
void Display_Else_Icon(unsigned char flag, unsigned long dat)
{
  unsigned char i,j;
  unsigned char p3, p4, p5, p6, p7, p8, p9, p10;
    
  
  if(DISP_STAT_IR==flag)
  {
    Display_HongWaiChinese_Icon();
    return;
  }
  
  p10 = dat/10000000;
  p9 = (dat%10000000)/1000000;
  p8 = (dat%1000000)/100000;
  p7 = (dat%100000)/10000;
  p6 = (dat%10000)/1000;
  p5 = (dat%1000)/100;
  p4 = (dat%100)/10;
  p3 = dat%10;
  
  if(flag==DISP_STAT_TEMP)
  {
    //p6=p5;
    //p5=p4;
    //p3=10;
  } 

    for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
      for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
        for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
  for(i = 4; i < 6; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  } 
  
  if( (DISP_STAT_TIMEF==flag) || (DISP_STAT_TIMEU==flag) || (DISP_STAT_TIMED==flag) ) 
  {
    if( p10 != 0 )
    {
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x14);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p10,i);
        LCD_CS1;
      }
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x14);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p9,i);
        LCD_CS1;
      }  
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p8,i);
        LCD_CS1;
      } 
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p7,i);
        LCD_CS1;
      } 
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x16);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p6,i);
        LCD_CS1;
      } 
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x16);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p5,i);
        LCD_CS1;
      }
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x17);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p4,i);
        LCD_CS1;
      }   
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x17);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p3,i);
        LCD_CS1;
      }     
    }
    else
    {
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x14);
        Write_LCD_COM(0x00);
        for(j = 0; j < 8; j++)
        {
          Write_LCD_DATA(0x00);
        }
        LCD_CS1;
      }    
      if( p9 != 0 )
      {
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p9,i);
          LCD_CS1;
        }  
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(p8,i);
          LCD_CS1;
        } 
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p7,i);
          LCD_CS1;
        } 
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x16);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(p6,i);
          LCD_CS1;
        } 
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x16);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p5,i);
          LCD_CS1;
        }  
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x17);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(p4,i);
          LCD_CS1;
        }   
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x17);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p3,i);
          LCD_CS1;
        }       
      }
      else
      {
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x08);
          for(j = 0; j < 8; j++)
          {
            Write_LCD_DATA(0x00);
          }
          LCD_CS1;
        }
        if( p8 != 0 )
        {
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x15);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(p8,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x15);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(p7,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x16);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(p6,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x16);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(p5,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x17);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(p4,i);
            LCD_CS1;
          }   
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x17);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(p3,i);
            LCD_CS1;
          }         
        }
        else
        {
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x15);
            Write_LCD_COM(0x00);
            for(j = 0; j < 8; j++)
            {
              Write_LCD_DATA(0x00);
            }
            LCD_CS1;
          } 
          if( p7 != 0 )
          {
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x15);
              Write_LCD_COM(0x08);
              Display_Switch_DateNumber(p7,i);
              LCD_CS1;
            } 
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x16);
              Write_LCD_COM(0x00);
              Display_Switch_DateNumber(p6,i);
              LCD_CS1;
            } 
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x16);
              Write_LCD_COM(0x08);
              Display_Switch_DateNumber(p5,i);
              LCD_CS1;
            } 
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x17);
              Write_LCD_COM(0x00);
              Display_Switch_DateNumber(p4,i);
              LCD_CS1;
            }   
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x17);
              Write_LCD_COM(0x08);
              Display_Switch_DateNumber(p3,i);
              LCD_CS1;
            }       
            
          }
          else
          {
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x15);
              Write_LCD_COM(0x08);
              for(j = 0; j < 8; j++)
              {
                Write_LCD_DATA(0x00);
              }
              LCD_CS1;
            }
            if( p6 != 0 )
            {
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x16);
                Write_LCD_COM(0x00);
                Display_Switch_DateNumber(p6,i);
                LCD_CS1;
              } 
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x16);
                Write_LCD_COM(0x08);
                Display_Switch_DateNumber(p5,i);
                LCD_CS1;
              } 
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x17);
                Write_LCD_COM(0x00);
                Display_Switch_DateNumber(p4,i);
                LCD_CS1;
              }   
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x17);
                Write_LCD_COM(0x08);
                Display_Switch_DateNumber(p3,i);
                LCD_CS1;
              }              
            }
            else
            {
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x16);
                Write_LCD_COM(0x00);
                for(j = 0; j < 8; j++)
                {
                  Write_LCD_DATA(0x00);
                }
                LCD_CS1;
              }
              if( p5 != 0 )
              {
                for(i = 4; i < 6; i++)
                {
                  LCD_CS0;
                  Write_LCD_COM(0xb0 + i);
                  Write_LCD_COM(0x16);
                  Write_LCD_COM(0x08);
                  Display_Switch_DateNumber(p5,i);
                  LCD_CS1;
                }  
                for(i = 4; i < 6; i++)
                {
                  LCD_CS0;
                  Write_LCD_COM(0xb0 + i);
                  Write_LCD_COM(0x17);
                  Write_LCD_COM(0x00);
                  Display_Switch_DateNumber(p4,i);
                  LCD_CS1;
                }   
                for(i = 4; i < 6; i++)
                {
                  LCD_CS0;
                  Write_LCD_COM(0xb0 + i);
                  Write_LCD_COM(0x17);
                  Write_LCD_COM(0x08);
                  Display_Switch_DateNumber(p3,i);
                  LCD_CS1;
                }   
              }
              else
              {
                for(i = 4; i < 6; i++)
                {
                  LCD_CS0;
                  Write_LCD_COM(0xb0 + i);
                  Write_LCD_COM(0x16);
                  Write_LCD_COM(0x08);
                  for(j = 0; j < 8; j++)
                  {
                    Write_LCD_DATA(0x00);
                  }
                  LCD_CS1;
                }
                if( p4 != 0 )
                {
                  for(i = 4; i < 6; i++)
                  {
                    LCD_CS0;
                    Write_LCD_COM(0xb0 + i);
                    Write_LCD_COM(0x17);
                    Write_LCD_COM(0x00);
                    Display_Switch_DateNumber(p4,i);
                    LCD_CS1;
                  }   
                  for(i = 4; i < 6; i++)
                  {
                    LCD_CS0;
                    Write_LCD_COM(0xb0 + i);
                    Write_LCD_COM(0x17);
                    Write_LCD_COM(0x08);
                    Display_Switch_DateNumber(p3,i);
                    LCD_CS1;
                  } 
             
                }
                else
                {
                   for(i = 4; i < 6; i++)
                  {
                    LCD_CS0;
                    Write_LCD_COM(0xb0 + i);
                    Write_LCD_COM(0x17);
                    Write_LCD_COM(0x00);
                    for(j = 0; j < 8; j++)
                    {
                      Write_LCD_DATA(0x00);
                    }
                    LCD_CS1;
                  } 
                  for(i = 4; i < 6; i++)
                  {
                    LCD_CS0;
                    Write_LCD_COM(0xb0 + i);
                    Write_LCD_COM(0x17);
                    Write_LCD_COM(0x08);
                    Display_Switch_DateNumber(p3,i);
                    LCD_CS1;
                  }                
                }
              }
            }
          }      
        }
        
      }
    }
  }
  else
  {
    if( p10 != 0 )
    {
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x13);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p10,i);
        LCD_CS1;
      }
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x13);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p9,i);
        LCD_CS1;
      }
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x14);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p8,i);
        LCD_CS1;
      }
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x14);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p7,i);
        LCD_CS1;
      }  
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p6,i);
        LCD_CS1;
      } 
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p5,i);
        LCD_CS1;
      } 
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x16);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(p4,i);
        LCD_CS1;
      } 
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x16);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(p3,i);
        LCD_CS1;
      }    
    }
    else
    {
      for(i = 4; i < 6; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x13);
        Write_LCD_COM(0x00);
        for(j = 0; j < 8; j++)
        {
          Write_LCD_DATA(0x00);
        }
        LCD_CS1;
      }    
      if( p9 != 0 )
      {
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x13);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p9,i);
          LCD_CS1;
        }  
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(p8,i);
          LCD_CS1;
        } 
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p7,i);
          LCD_CS1;
        } 
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(p6,i);
          LCD_CS1;
        } 
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p5,i);
          LCD_CS1;
        }  
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x16);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(p4,i);
          LCD_CS1;
        } 
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x16);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(p3,i);
          LCD_CS1;
        }           
      }
      else
      {
        for(i = 4; i < 6; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x13);
          Write_LCD_COM(0x08);
          for(j = 0; j < 8; j++)
          {
            Write_LCD_DATA(0x00);
          }
          LCD_CS1;
        }
        if( p8 != 0 )
        {
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x14);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(p8,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x14);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(p7,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x15);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(p6,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x15);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(p5,i);
            LCD_CS1;
          }  
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x16);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(p4,i);
            LCD_CS1;
          } 
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x16);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(p3,i);
            LCD_CS1;
          }           
        }
        else
        {
          for(i = 4; i < 6; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x14);
            Write_LCD_COM(0x00);
            for(j = 0; j < 8; j++)
            {
              Write_LCD_DATA(0x00);
            }
            LCD_CS1;
          } 
          if( p7 != 0 )
          {
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x14);
              Write_LCD_COM(0x08);
              Display_Switch_DateNumber(p7,i);
              LCD_CS1;
            } 
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x15);
              Write_LCD_COM(0x00);
              Display_Switch_DateNumber(p6,i);
              LCD_CS1;
            } 
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x15);
              Write_LCD_COM(0x08);
              Display_Switch_DateNumber(p5,i);
              LCD_CS1;
            } 
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x16);
              Write_LCD_COM(0x00);
              Display_Switch_DateNumber(p4,i);
              LCD_CS1;
            } 
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x16);
              Write_LCD_COM(0x08);
              Display_Switch_DateNumber(p3,i);
              LCD_CS1;
            }             
          }
          else
          {
            for(i = 4; i < 6; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x14);
              Write_LCD_COM(0x08);
              for(j = 0; j < 8; j++)
              {
                Write_LCD_DATA(0x00);
              }
              LCD_CS1;
            }
            if( p6 != 0 )
            {
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x15);
                Write_LCD_COM(0x00);
                Display_Switch_DateNumber(p6,i);
                LCD_CS1;
              } 
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x15);
                Write_LCD_COM(0x08);
                Display_Switch_DateNumber(p5,i);
                LCD_CS1;
              }
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x16);
                Write_LCD_COM(0x00);
                Display_Switch_DateNumber(p4,i);
                LCD_CS1;
              } 
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x16);
                Write_LCD_COM(0x08);
                Display_Switch_DateNumber(p3,i);
                LCD_CS1;
              }               
            }
            else
            {
              for(i = 4; i < 6; i++)
              {
                LCD_CS0;
                Write_LCD_COM(0xb0 + i);
                Write_LCD_COM(0x15);
                Write_LCD_COM(0x00);
                for(j = 0; j < 8; j++)
                {
                  Write_LCD_DATA(0x00);
                }
                LCD_CS1;
              }
              if( p5 != 0 )
              {
                for(i = 4; i < 6; i++)
                {
                  LCD_CS0;
                  Write_LCD_COM(0xb0 + i);
                  Write_LCD_COM(0x15);
                  Write_LCD_COM(0x08);
                  Display_Switch_DateNumber(p5,i);
                  LCD_CS1;
                }
                for(i = 4; i < 6; i++)
                {
                  LCD_CS0;
                  Write_LCD_COM(0xb0 + i);
                  Write_LCD_COM(0x16);
                  Write_LCD_COM(0x00);
                  Display_Switch_DateNumber(p4,i);
                  LCD_CS1;
                } 
                for(i = 4; i < 6; i++)
                {
                  LCD_CS0;
                  Write_LCD_COM(0xb0 + i);
                  Write_LCD_COM(0x16);
                  Write_LCD_COM(0x08);
                  Display_Switch_DateNumber(p3,i);
                  LCD_CS1;
                }                 
              }
              else
              {
                  for(i = 4; i < 6; i++)
                  {
                    LCD_CS0;
                    Write_LCD_COM(0xb0 + i);
                    Write_LCD_COM(0x15);
                    Write_LCD_COM(0x08);
                    for(j = 0; j < 8; j++)
                    {
                      Write_LCD_DATA(0x00);
                    }
                    LCD_CS1;
                  }
                  if( p4 != 0 )  
                  {
                    for(i = 4; i < 6; i++)
                    {
                      LCD_CS0;
                      Write_LCD_COM(0xb0 + i);
                      Write_LCD_COM(0x16);
                      Write_LCD_COM(0x00);
                      Display_Switch_DateNumber(p4,i);
                      LCD_CS1;
                    } 
                    for(i = 4; i < 6; i++)
                    {
                      LCD_CS0;
                      Write_LCD_COM(0xb0 + i);
                      Write_LCD_COM(0x16);
                      Write_LCD_COM(0x08);
                      Display_Switch_DateNumber(p3,i);
                      LCD_CS1;
                    }                    
                  }
                  else
                  {
                      for(i = 4; i < 6; i++)
                      {
                        LCD_CS0;
                        Write_LCD_COM(0xb0 + i);
                        Write_LCD_COM(0x16);
                        Write_LCD_COM(0x00);
                        for(j = 0; j < 8; j++)
                        {
                          Write_LCD_DATA(0x00);
                        }
                        LCD_CS1;
                      }
                      for(i = 4; i < 6; i++)
                      {
                        LCD_CS0;
                        Write_LCD_COM(0xb0 + i);
                        Write_LCD_COM(0x16);
                        Write_LCD_COM(0x08);
                        Display_Switch_DateNumber(p3,i);
                        LCD_CS1;
                      }                       
                  }              
              }            
            }
          }      
        }   
      }
    }    
  }
  
  
  switch(flag)
  {
    case DISP_STAT_MAIN:
    {
      Display_LiuLiangDotChinese_Icon();
      break;
    }
    case DISP_STAT_SPEED:
    {
      Display_LiuSuChinese_Icon();
      break;
    }    
    case DISP_STAT_TEMP:
    {
      Display_WenDuChinese_Icon();
      break;
    } 
    case DISP_STAT_TIMEF:
    case DISP_STAT_TIMEU:
    case DISP_STAT_TIMED:      
    {
      Display_TimeOfFlight_Icon(flag);
      break;
    } 
    case DISP_STAT_IR:
    {
      Display_HongWaiChinese_Icon();
      break;
    }    
    default:
      break;
  }
   
}

//˳����ͷ��ͼ����ʾ
void Display_up_Icon(unsigned char flag)
{
  unsigned char i,j,adressd = 0;

  for(i = 0; i < 1; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    if(flag)
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(graphic_up_icon[adressd]);
        adressd++;
      }
    }
    else
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(0x00);//����ű���ͼ��
      }
    }
    LCD_CS1;
  }
   
}

//������ͷ��ͼ����ʾ
void Display_down_Icon(unsigned char flag)
{
  unsigned char i,j,adressd = 0;
  for(i = 0; i < 1; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    if(flag)
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(graphic_down_icon[adressd]);
        adressd++;
      }
    }
    else
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(0x00);//����·�ͼ��
      }
    }
    LCD_CS1;
  }
    
}


void Display_Switch_CumNumber(unsigned char num, unsigned char hang, unsigned char flag)
{
  unsigned char k = 0;
  switch(num)
  {
  case 0:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber0_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber0_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber0_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber0leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber0leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber0leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber0rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber0rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber0rightdot_icon[k + 24]);
        }
      }
      break;
    }
  case 1:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber1_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber1_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber1_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber1leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber1leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber1leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber1rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber1rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber1rightdot_icon[k + 24]);
        }
      }
      break;
    }
  case 2:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber2_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber2_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber2_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber2leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber2leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber2leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber2rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber2rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber2rightdot_icon[k + 24]);
        }
      }
      break;
    }
  case 3:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber3_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber3_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber3_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber3leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber3leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber3leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber3rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber3rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber3rightdot_icon[k + 24]);
        }
      }
      break;
    }
  case 4:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber4_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber4_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber4_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber4leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber4leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber4leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber4rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber4rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber4rightdot_icon[k + 24]);
        }
      }
      break;
    }
  case 5:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber5_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber5_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber5_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber5leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber5leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber5leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber5rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber5rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber5rightdot_icon[k + 24]);
        }
      }
      break;
    }
  case 6:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber6_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber6_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber6_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber6leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber6leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber6leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber6rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber6rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber6rightdot_icon[k + 24]);
        }
      }
      break;
    }
   case 7:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber7_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber7_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber7_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber7leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber7leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber7leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber7rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber7rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber7rightdot_icon[k + 24]);
        }
      }
      break;
    }
   case 8:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber8_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber8_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber8_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber8leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber8leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber8leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber8rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber8rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber8rightdot_icon[k + 24]);
        }
      }
      break;
    }
   case 9:
    {
      for(k = 0; k < 12; k++)
      {
        if(flag == 0)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber9_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber9_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber9_icon[k + 24]);
        }
        else if(flag == 1)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber9leftdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber9leftdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber9leftdot_icon[k + 24]);
        }
        else if(flag == 2)
        {
          if(hang == 1)
            Write_LCD_DATA(graphic_cumnmuber9rightdot_icon[k]);
          else if(hang == 2)
            Write_LCD_DATA(graphic_cumnmuber9rightdot_icon[k + 12]);
          else if(hang == 3)
            Write_LCD_DATA(graphic_cumnmuber9rightdot_icon[k + 24]);
        }
      }
      break;
    }
   default: break;   
  }
}

//���ۻ�����ʾ
void Display_Cum_Icon(unsigned long cum)
{
  unsigned char i,j,adressd = 0;
  unsigned char dian,ge,shi,bai,qian,temp2;
  cum = cum%100000;
  qian = cum/10000;
  bai = (cum%10000)/1000;
  shi = (cum%1000)/100;
  ge = (cum%100)/10;
  dian = cum%10;
  
  //clear
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x04);
    for(j = 0; j < 12; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x00);
    for(j = 0; j < 12; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x0c);
    for(j = 0; j < 12; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x08);
    for(j = 0; j < 12; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x04);
    for(j = 0; j < 12; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    for(j = 0; j < 12; j++)
    {
      Write_LCD_DATA(0x00);
    }
    LCD_CS1;
  }
  
  //qian
  if(qian)
  {
        //qian
        for(i = 1; i < 4; i++)
        {
          temp2 = 0;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x13);
          Write_LCD_COM(0x04);
          Display_Switch_CumNumber(qian,i,temp2);
          LCD_CS1;
        }
        //bai
        for(i = 1; i < 4; i++)
        {
          temp2 = 0;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x00);
          Display_Switch_CumNumber(bai,i,temp2);
          LCD_CS1;
        }
        //shi
        for(i = 1; i < 4; i++)
        {
          temp2 = 0;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x0c);
          Display_Switch_CumNumber(shi,i,temp2);
          LCD_CS1;
        }
        //ge
        for(i = 1; i < 4; i++)
        {
          temp2 = 2;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_CumNumber(ge,i,temp2);
          LCD_CS1;
        }     
  }
  else
  {
    //bai
    if(bai)
    {
        //bai
        for(i = 1; i < 4; i++)
        {
          temp2 = 0;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x00);
          Display_Switch_CumNumber(bai,i,temp2);
          LCD_CS1;
        }
        //shi
        for(i = 1; i < 4; i++)
        {
          temp2 = 0;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x0c);
          Display_Switch_CumNumber(shi,i,temp2);
          LCD_CS1;
        }
        //ge
        for(i = 1; i < 4; i++)
        {
          temp2 = 2;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_CumNumber(ge,i,temp2);
          LCD_CS1;
        }     
    }
    else
    {
      //shi
      if(shi)
      {
        //shi
        for(i = 1; i < 4; i++)
        {
          temp2 = 0;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x14);
          Write_LCD_COM(0x0c);
          Display_Switch_CumNumber(shi,i,temp2);
          LCD_CS1;
        }
        //ge
        for(i = 1; i < 4; i++)
        {
          temp2 = 2;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_CumNumber(ge,i,temp2);
          LCD_CS1;
        } 
      }
      else
      {
        //ge
        for(i = 1; i < 4; i++)
        {
          temp2 = 2;
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_CumNumber(ge,i,temp2);
          LCD_CS1;
        }          
      }
    }
  }
    
    
  
  //dian
  for(i = 1; i < 4; i++)
  {
    temp2 = 1;
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x04);
    Display_Switch_CumNumber(dian,i,temp2);
    LCD_CS1;
  }
  //��λ
  adressd = 0;
  for(i = 1; i < 4; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    for(j = 0; j < 12; j++)
    {
      Write_LCD_DATA(graphic_cumunit_icon[adressd]);
      adressd++;
    }
    LCD_CS1;
  }
  
}

//LCDˢ��
void LCD_ReFlash(void)
{
  Display_CumChinese_Icon();
  
  //�չܱ���ͼ����ʾ����
  Display_Magnetic_Icon(0);
  
  //���ʣ�����ͼ����ʾ����
  Display_Battery_Icon(g_batteryLevel);  
  
  //�ۻ���������ʾ����
  Display_Cum_Icon((unsigned long)WfmInfo.Normal.TotalVolume);
  
  //������Ϣ��ʾ
  Display_Else_Icon(DISP_STAT_MAIN,(unsigned long)WfmInfo.Normal.TotalVolumeDecimal);
  
  rtcGetDateTimeBCD((uchar *)&g_tagRTC); //��ȡˮ����ǰʱ��
  //������ʾ����
  Display_Date_Icon( g_tagRTC.g_Year, g_tagRTC.g_Month, g_tagRTC.g_Day, g_tagRTC.g_Hour, g_tagRTC.g_Minite);
}
