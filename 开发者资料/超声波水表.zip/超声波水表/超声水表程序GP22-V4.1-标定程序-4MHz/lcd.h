#ifndef __LCD_H
#define __LCD_H



#define LCD_CS1         P4OUT |= BIT3                   //LCD_CS�øߵ�ƽ 
#define LCD_CS0         P4OUT &= ~BIT3                  //LCD_CS�õ͵�ƽ
#define LCD_RST1        P4OUT |= BIT5                   //LCD_RST�øߵ�ƽ 
#define LCD_RST0        P4OUT &= ~BIT5                 //LCD_RST�õ͵�ƽ
#define LCD_A01         P4OUT |= BIT4                   //LCD_A0�øߵ�ƽ 
#define LCD_A00         P4OUT &= ~BIT4                  //LCD_A0�õ͵�ƽ
#define LCD_SCL1        P4OUT |= BIT0                   //LCD_SCL�øߵ�ƽ 
#define LCD_SCL0        P4OUT &= ~BIT0                  //LCD_SCL�õ͵�ƽ
#define LCD_SDA1        P4OUT |= BIT2                   //LCD_SDA�øߵ�ƽ 
#define LCD_SDA0        P4OUT &= ~BIT2                  //LCD_SDA�õ͵�ƽ


//#define LCD_BackLight11  P3OUT |= BIT7                   //LCD_BackLight�øߵ�ƽ 
//#define LCD_BackLight10  P3OUT &= ~BIT7                  //LCD_BackLight�õ͵�ƽ
//#define LCD_Power1      P4OUT |= BIT0                   //LCD_Power�øߵ�ƽ 
//#define LCD_Power0      P4OUT &= ~BIT0                  //LCD_Power�õ͵�ƽ



void InitLCD(void);
void OpenLCD(void);
void CloseLCD(void);
void Display_Battery_Icon(unsigned char battery_capacity);
void Display_Magnetic_Icon(unsigned char flag);
void Display_VmL_Icon(void);
void Display_TOFPs_Icon(void);
void Display_up_Icon(unsigned char flag);
void Display_Tof_Icon(unsigned long cum);
void Display_Cum_Icon(unsigned long cum);
void LCD_ReFlash(void);

#endif 