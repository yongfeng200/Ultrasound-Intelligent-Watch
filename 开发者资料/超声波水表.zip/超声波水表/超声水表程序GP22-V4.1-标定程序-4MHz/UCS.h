
#ifndef __UCS_H
#define __UCS_H

extern void initUCS(void); 

#endif 