#include "params.h"


/*****************************************************
*The related parameters of step tariffing water meter.
*****************************************************/
struct tagSysPara    g_systemPara;


/******************************************************
*The related parameters of water meter accumulation.
******************************************************/
struct tagAccumulationPara  g_accumulationPara;


/******************************************************
*The related parameters of external trigger event.
******************************************************/
unsigned int g_ExternalTriggerEvent             = 0;


/******************************************************
*The related parameters of RTC.
******************************************************/
unsigned char g_RTCReadWriteBuffer[7];


/******************************************************
*The related parameters of SVD.
******************************************************/
unsigned char g_svdStartflag                     = 0;
unsigned char g_svdLowVoltageDetectNumber        = 0;
unsigned char g_batteryLevel                     = 5;


/******************************************************
*The related parameters of LCD.
******************************************************/
unsigned char g_hourDisplay                      = 0;
unsigned char g_dayDisplay                       = 0;
unsigned char g_monthDisplay                     = 0;
unsigned char g_yearDisplay                      = 0;
unsigned long g_accumulationTotalDisplay         = 0;


/******************************************************
*The related parameters of TDC.
******************************************************/
volatile unsigned char g_tdcInterruptFlag                 = 0;
unsigned int  g_tdcStatusRegister                = 0;
unsigned long g_tdcTimeOutCount                  = 0;

float         g_calibrateResult                  = 0;
float         g_calibrateCorrectionFactor        = 0;

unsigned char g_numberOfTemperatureMeasure       = 1;
float         g_temperature1Result0              = 0;
float         g_temperature1Result1              = 0;
float         g_temperature1Result2              = 0;
float         g_temperature1Result3              = 0;
float         g_temperature2Result0              = 0;
float         g_temperature2Result1              = 0;
float         g_temperature2Result2              = 0;
float         g_temperature2Result3              = 0;
float         g_RhotByRref                       = 0;
float         g_RcoldByRref                      = 0;

float         g_timeResult0                      = 0;
float         g_timeResult1                      = 0;
float         g_timeResult2                      = 0;
float         g_timeResult3                      = 0;
float         g_averageTimeResultUp              = 0;
float         g_averageTimeResultDown            = 0;
float         g_PW1STValue                       = 0;
 long         g_timeOfFlight                     = 0;
 long         g_timeOfFlight_ave                 = 0;
 long         g_timeOfFlightBuffer[10]           = {0,0,0,0,0,0,0,0,0,0};
 long         g_tofDisplay                       = 0;
float         g_waterLineSpeed                   = 0;
float         g_waterSurfaceSpeed                = 0;
float         g_accumulationAmount               = 0;
float         g_tempAccumulationAmount           = 0;
unsigned char g_hitCount                         = 1;
unsigned char g_streamCount                      = 1;
unsigned char g_upStreamFlag                     = 0;
unsigned char g_upTimeOutFlag                    = 0;
unsigned char g_downTimeOutFlag                  = 0;
unsigned char g_oneSecondAccumulationFlag        = 0;
unsigned char g_startAccumulationFlag            = 0;
unsigned char g_startAccumulationCount           = 0;
unsigned char g_endAccumulationCount             = 0;

unsigned char g_valueOpenFlag                    = 0;//���ſ��ر�־
unsigned char g_valueOpenCount                   = 0;//���ſ��ر�־