.\0.96oled7pinspi.o: 0.96OLED7PINSPI.C
