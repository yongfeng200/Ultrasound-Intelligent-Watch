/***************************************************************************
 *
 * @file	params.h
 * @brief	This is system whole params header file(C17W15).
 *
 * @par		Copyright:
 *			Copyright (C) HS-WuTing 2015. All rights reserved.
 *
 * @warning -
 *
 * @par		History:
 *			- 15/07/2015    1.0
 *				- First revision.
 *
 **************************************************************************/

#ifndef PARAMS_H__
#define PARAMS_H__


struct tagSysPara
{
  unsigned char        szTermID[7];               /// Water meter address.
  //unsigned char        szUserID[32];              /// Water meter family code.
};
extern struct tagSysPara  g_systemPara;


#define	WATERFLOW_COEFF_MAX_COUNT 16

typedef struct {
	unsigned long 	TotalVolume; // 1L/10000
	unsigned long 	TotalVolumeDecimal;  //Decimal*10000
	unsigned long 	TotalVolumeSave; // 1L/10000
	unsigned long 	TotalVolumeDecimalSave;  //Decimal*10000        
	float	InstantFlowRate;	//��ǰ����
	float	InstantFrequence;	//��ǰƵ��
	unsigned short	InstantInterval;	//
} FLOW_ST;

typedef struct {
	unsigned char m_state;
	unsigned char m_direction;			//����Ԥ��
	unsigned long m_upper_threshold;	//���ޱ���ֵ
	unsigned long m_low_threshold;		//���ޱ���ֵ
	unsigned char m_pulse_volume;		//����������� 1�� 0.01��2��0.001
	unsigned long m_freq[WATERFLOW_COEFF_MAX_COUNT];
	unsigned long m_velocity[WATERFLOW_COEFF_MAX_COUNT];
	long m_freq_buchang[WATERFLOW_COEFF_MAX_COUNT];
	unsigned short m_coeff_count;
} WFM_PARAMETER ;

typedef struct {
	unsigned char		State;
	WFM_PARAMETER		Config;
	FLOW_ST				Normal;
	FLOW_ST				Reverse;

	unsigned char 		WaterFlow_Direction;	//��ǰ����
	unsigned char 		WaterFlow_Warn;			//����
	unsigned short		Interval;				//timer interval by msec
	float		TotalNormalCount;
	float		TotalReverseCount;
}WFM_INFO;

typedef struct {
	float Normal_SumCnt;
	float Reverse_SumCnt;
	unsigned short NormalDuration;
	unsigned short ReverseDuration;
	float NormalCntPre;
	float ReverseCntPre;
} WFMCOUNTINFO;

extern WFMCOUNTINFO WFMCountInfo;
extern WFM_INFO	WfmInfo;

/******************************************************
*The related parameters of water meter accumulation.
******************************************************/
struct tagAccumulationPara
{
  unsigned long accumulationBase;
  unsigned long accumulationPositive;
  unsigned long accumulationNegative;
  unsigned long accumulationTotal;
};
extern struct tagAccumulationPara  g_accumulationPara;

extern unsigned long g_Turn_Number_Zheng,g_Turn_Number_Fu,g_Total_Number,g_Jishu_Number;

/******************************************************
*The related parameters of external trigger event.
******************************************************/
/******************************************************
*�ⲿ�����¼���ر���
******************************************************/
#define TRI_IR            0x0001    //����ң�ذ�������
#define TRI_RTC           0x0002    //RTC�ж�
#define TRI_KEYPRESS_L    0x0004    //��������(�̰�)
#define TRI_KEYPRESS_LL   0x0008    //��������(�а�)
#define TRI_KEYPRESS_LLL  0x0010    //��������(����)


extern unsigned int g_externalTriggerEvent;


/******************************************************
*RTC��ر���
******************************************************/
struct tagRTC
{
  unsigned char g_Second;   
  unsigned char g_Minite;
  unsigned char g_Hour;   
  unsigned char g_Weekday; 
  unsigned char g_Day;   
  unsigned char g_Month;  
  unsigned char g_Year;
};
extern struct tagRTC  g_tagRTC;
extern unsigned char g_rtcTempBuffer[7];
extern unsigned char g_rtcAlarmMinTime;
extern unsigned char g_rtcAlarmHourTime;



/******************************************************
*����ͨ��������ʾ��ر���
******************************************************/
#define  IR_MAX_RECEIVE_BUFFER    50  /// Define the size of IR receive buffer.
#define  IR_MAX_SEND_BUFFER       80  /// Define the size of IR send buffer.

extern unsigned char g_irReceiveBuffer[IR_MAX_RECEIVE_BUFFER];
extern unsigned char g_irSendBuffer[IR_MAX_SEND_BUFFER];
extern unsigned char g_irSendByteNumberCount;
extern unsigned char g_irReceiveByteNumberCount;
extern unsigned char g_irReceiveCode;
extern unsigned char g_irReceiveByteOkFlag;
extern unsigned char g_irReceiveOrSendFlag;


/******************************************************
*���ݴ洢��ر���
******************************************************/
#define  Flash_Save_Buffer_Lenth       700  
extern unsigned char g_DataSave_Buffer[700];



/******************************************************
*The related parameters of CJ188 communication.
******************************************************/
#define  UART_MAX_RECEIVE_BUFFER    50  /// Define the size of UART receive buffer.
#define  UART_MAX_SEND_BUFFER       50  /// Define the size of UART send buffer.

extern unsigned char g_uartReceiveBuffer[UART_MAX_RECEIVE_BUFFER];
extern unsigned char g_uartSendBuffer[UART_MAX_SEND_BUFFER];
extern unsigned char g_uartSendByteNumberCount;
extern unsigned char g_uartReceiveByteNumberCount;
extern unsigned char g_uartReceiveCode;
extern unsigned char g_uartCommunicationSuccessFlag;
extern unsigned char g_uartCommunicationTimeoutFlag;


/******************************************************
*The related parameters of SVD.
******************************************************/
extern unsigned char g_svdStartflag;
extern unsigned char g_svdLowVoltageDetectNumber;
extern unsigned char g_batteryLevel;


/******************************************************
*The related parameters of LCD.
******************************************************/
#define DISP_STAT_CLOSE         0   /// Menu of close LCD
#define DISP_STAT_MAIN          1   /// Menu of main
#define DISP_STAT_SPEED         2   /// Menu of speed
#define DISP_STAT_TEMP          3   /// Menu of temp
#define DISP_STAT_TIMEF         4   /// Menu of time flight
#define DISP_STAT_TIMEU         5   /// Menu of time up
#define DISP_STAT_TIMED         6   /// Menu of time down
#define DISP_STAT_IR            7   /// Menu of ir

extern unsigned char g_displayState;

extern unsigned char g_hourDisplay;
extern unsigned char g_dayDisplay;
extern unsigned char g_monthDisplay;
extern unsigned char g_yearDisplay;
extern unsigned long g_accumulationTotalDisplay;

extern unsigned char g_KeyInteruptDown_Flag;


/******************************************************
*The related parameters of TDC.
******************************************************/
extern volatile unsigned char g_tdcInterruptFlag;
extern unsigned int  g_tdcStatusRegister;
extern unsigned long g_tdcTimeOutCount;

extern float         g_calibrateResult;
extern float         g_calibrateCorrectionFactor;

extern unsigned char g_numberOfTemperatureMeasure;
extern float         g_temperature1Result0;
extern float         g_temperature1Result1;
extern float         g_temperature1Result2;
extern float         g_temperature1Result3;
extern float         g_temperature2Result0;
extern float         g_temperature2Result1;
extern float         g_temperature2Result2;
extern float         g_temperature2Result3;
extern float         g_RhotByRref;
extern float         g_RcoldByRref;

extern float         g_timeResult0;
extern float         g_timeResult1;
extern float         g_timeResult2;
extern float         g_timeResult3;
extern float         g_averageTimeResultUp;
extern float         g_averageTimeResultDown;
extern float         g_PW1STValue;
extern long         g_timeOfFlight;
extern long         g_timeOfFlight_ave;
extern long         g_timeOfFlightBuffer[10];
extern long         g_tofDisplay;
extern float         g_waterLineSpeed;
extern float         g_waterSurfaceSpeed;
extern float         g_waterSurfaceSpeedDisp;
extern float         g_accumulationAmount;
extern float         g_tempAccumulationAmount;
extern unsigned char g_hitCount;
extern unsigned char g_streamCount;
extern unsigned char g_upStreamFlag;
extern unsigned char g_upTimeOutFlag;
extern unsigned char g_downTimeOutFlag;
extern unsigned char g_oneSecondAccumulationFlag;
extern unsigned char g_startAccumulationFlag;
extern unsigned char g_startAccumulationCount;
extern unsigned char g_endAccumulationCount;

extern unsigned char g_valueOpenFlag;//���ſ��ر�־
extern unsigned char g_valueOpenCount;//���ſ��ر�־

extern unsigned int  g_tempValue;
extern float         g_tempHot;
extern float         g_tempClod;
extern unsigned int  g_tempTableP;
extern unsigned char g_tdcTimeOutFlag;


#endif  // PARAMS_H__
