#include "msp430x54x.h"
#include "Functions.h"
#include "Params.h"
#include "LCD.h"

const unsigned char graphic_battery0_icon[]=
{0x00,0x3C,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��0��16-8.BMP*/

const unsigned char graphic_battery1_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��1��16-8.BMP*/

const unsigned char graphic_battery2_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x42,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��2��16-8.BMP*/

const unsigned char graphic_battery3_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x42,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��3��16-8.BMP*/

const unsigned char graphic_battery4_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x42,0x42,0x3C,0x3C,0x00};/*���ͼ��4��16-8.BMP*/

const unsigned char graphic_battery5_icon[]=
{0x00,0x3C,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x5A,0x42,0x3C,0x3C,0x00};/*���ͼ��5��16-8.BMP*/

const unsigned char graphic_magnetic_icon[]=
{0x00,0x3C,0x72,0xF9,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE5,0xE7,0x00};/*�Ÿ�����ʾͼ��16-8.BMP*/

const unsigned char graphic_acii_V_icon[]=
{0x08,0x78,0x88,0x00,0x00,0xC8,0x38,0x08,0x00,0x00,0x07,0x38,0x0E,0x01,0x00,0x00};/*"V",0*/

const unsigned char graphic_acii_maohao_icon[]=
{0x00,0x00,0x00,0xC0,0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00};/*:*/

const unsigned char graphic_acii_T_icon[]=
{0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00};/*"T",0*/

const unsigned char graphic_acii_O_icon[]=
{0xE0,0x10,0x08,0x08,0x08,0x10,0xE0,0x00,0x0F,0x10,0x20,0x20,0x20,0x10,0x0F,0x00};/*"O",0*/

const unsigned char graphic_acii_F_icon[]=
{0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x00,0x03,0x00,0x00,0x00};/*"F",0*/

const unsigned char graphic_acii_N_icon[]=
{0x08,0xF8,0x30,0xC0,0x00,0x08,0xF8,0x08,0x20,0x3F,0x20,0x00,0x07,0x18,0x3F,0x00};/*"N",0*/

const unsigned char graphic_acii_s_icon[]=
{0x00,0x00,0x80,0x80,0x80,0x80,0x80,0x00,0x00,0x33,0x24,0x24,0x24,0x24,0x19,0x00};/*"s",0*/

const unsigned char graphic_acii_m_icon[]=
{0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x00,0x20,0x3F,0x20,0x00,0x3F,0x20,0x00,0x3F};/*"m",0*/

const unsigned char graphic_acii_L_icon[]=
{0x08,0xF8,0x08,0x00,0x00,0x00,0x00,0x00,0x20,0x3F,0x20,0x20,0x20,0x20,0x30,0x00};/*"L",0*/

const unsigned char graphic_acii_p_icon[]=
{0x80,0x80,0x00,0x80,0x80,0x00,0x00,0x00,0x80,0xFF,0xA1,0x20,0x20,0x11,0x0E,0x00};/*"p",0*/

const unsigned char graphic_datenumber0_icon[]=
{0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,0x00,0x0F,0x10,0x20,0x20,0x10,0x0F,0x00};/*��������0ͼ��8-16.BMP*/

const unsigned char graphic_datenumber1_icon[]=
{0x00,0x10,0x10,0xF8,0x00,0x00,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00};/*��������1ͼ��8-16.BMP*/

const unsigned char graphic_datenumber2_icon[]=
{0x00,0x70,0x08,0x08,0x08,0x88,0x70,0x00,0x00,0x30,0x28,0x24,0x22,0x21,0x30,0x00};/*��������2ͼ��8-16.BMP*/

const unsigned char graphic_datenumber3_icon[]=
{0x00,0x30,0x08,0x88,0x88,0x48,0x30,0x00,0x00,0x18,0x20,0x20,0x20,0x11,0x0E,0x00};/*��������3ͼ��8-16.BMP*/

const unsigned char graphic_datenumber4_icon[]=
{0x00,0x00,0xC0,0x20,0x10,0xF8,0x00,0x00,0x00,0x07,0x04,0x24,0x24,0x3F,0x24,0x00};/*��������4ͼ��8-16.BMP*/

const unsigned char graphic_datenumber5_icon[]=
{0x00,0xF8,0x08,0x88,0x88,0x08,0x08,0x00,0x00,0x19,0x21,0x20,0x20,0x11,0x0E,0x00};/*��������5ͼ��8-16.BMP*/

const unsigned char graphic_datenumber6_icon[]=
{0x00,0xE0,0x10,0x88,0x88,0x18,0x00,0x00,0x00,0x0F,0x11,0x20,0x20,0x11,0x0E,0x00};/*��������6ͼ��8-16.BMP*/

const unsigned char graphic_datenumber7_icon[]=
{0x00,0x38,0x08,0x08,0xC8,0x38,0x08,0x00,0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00};/*��������7ͼ��8-16.BMP*/

const unsigned char graphic_datenumber8_icon[]=
{0x00,0x70,0x88,0x08,0x08,0x88,0x70,0x00,0x00,0x1C,0x22,0x21,0x21,0x22,0x1C,0x00};/*��������8ͼ��8-16.BMP*/

const unsigned char graphic_datenumber9_icon[]=
{0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,0x00,0x00,0x31,0x22,0x22,0x11,0x0F,0x00};/*��������9ͼ��8-16.BMP*/


const unsigned char graphic_up_icon[]=
{0x00,0x00,0x00,0x00,0x08,0x0C,0xFE,0xFF,0xFE,0x0C,0x08,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x01,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00};/*����ͼ��16-16.BMP*/



//LCD��λ
void ResetLCD(void)
{
  LCD_RST0;
  delay_ms(2);
  for(int i = 0; i < 100; i++);
  _NOP();
  _NOP();
  _NOP();
  _NOP();
  LCD_RST1;
  delay_ms(4);
  for(int i = 0; i < 200; i++);
  _NOP();
  _NOP();
  _NOP();
  _NOP();
}

//LCDд����
void Write_LCD_COM(unsigned char COMDADA_4SPI)
{
  unsigned char bit8;
  LCD_A00;
  LCD_CS0;
  for(bit8 = 0; bit8 < 8; bit8++)
  {
    LCD_SCL0;
    if((COMDADA_4SPI & 0x80) == 0x80)
     LCD_SDA1;
    else		
     LCD_SDA0;
    LCD_SCL1;
    COMDADA_4SPI <<= 1;
  }
  LCD_CS1;
  LCD_A01;
  
}

//LCDд����
void Write_LCD_DATA(unsigned char DADA_4SPI)
{   
  unsigned char bit8;
  LCD_A01;
  LCD_CS0;				
  for(bit8 = 0; bit8 < 8; bit8++)
  {
    LCD_SCL0;
    if((DADA_4SPI & 0x80) == 0x80)
     LCD_SDA1;
    else
     LCD_SDA0;
    LCD_SCL1;
    DADA_4SPI <<= 1;
  }
    LCD_CS1;
  LCD_A01;
}

void Column_set(unsigned char column)
{
   Write_LCD_COM(0x10|(column>>4));
   Write_LCD_COM(0x00|(column&0x0f));
}

void Page_set(unsigned char page)
{
   Write_LCD_COM(0xb0+page);
}

//LCD����
void ClearLCD(unsigned char xx) //����
{               
  unsigned char i,j;
  for(i = 0; i < 8; i++)
  {
    //LCD_CS0;
    Page_set(i);
    Column_set(0);
    for(j = 0; j < 128 ; j++)
    {
      Write_LCD_DATA(xx);
    }
    //LCD_CS1;
   }
}

//LCD��ʼ��
void InitLCD(void)
{
  P4DIR |= BIT2;                //��Ϊ�������LCD_SDA��
  P4DIR |= BIT0;                //��Ϊ�������LCD_SCK��
  P4DIR |= BIT4;                //��Ϊ�������LCD_A0��
  P4DIR |= BIT5;                //��Ϊ�������LCD_RESET��
  P4DIR |= BIT3;                //��Ϊ�������LCD_CS��
  //P4DIR |= BIT0;                //��Ϊ�������LCD_BackLight��
  //P3DIR |= BIT7; 
  //P4DIR |= BIT0;                //��Ϊ�������LCD_power��
  
  
  LCD_CS0;
  //LCD_BackLight0;
  //LCD_Power0;
  
  //LCD_BackLight11;
  
  ResetLCD();
  //delay_ms(100);
  for(unsigned int i = 0; i < 4000; i++);
 Write_LCD_COM(0xae);	//--turn off oled panel

Write_LCD_COM(0x00);	//--set low column address
Write_LCD_COM(0x10);	//--set high column address

Write_LCD_COM(0x40);	//--set start line address

Write_LCD_COM(0xb0);	//--set page address

Write_LCD_COM(0x81);	//--set contrast control register
Write_LCD_COM(0xff);

Write_LCD_COM(0xa1);	//--set segment re-map 127 to 0   a0:0 to seg127
Write_LCD_COM(0xa6);	//--set normal display

Write_LCD_COM(0xc8);	//--set com(N-1)to com0  c0:com0 to com(N-1)

Write_LCD_COM(0xa8);	//--set multiples ratio(1to64)
Write_LCD_COM(0x3f);	//--1/64 duty

Write_LCD_COM(0xd3);	//--set display offset
Write_LCD_COM(0x00);	//--not offset

Write_LCD_COM(0xd5);	//--set display clock divide ratio/oscillator frequency
Write_LCD_COM(0x80);	//--set divide ratio

Write_LCD_COM(0xd9);	//--set pre-charge period
Write_LCD_COM(0xf1);

Write_LCD_COM(0xda);	//--set com pins hardware configuration
Write_LCD_COM(0x12);

Write_LCD_COM(0xdb);	//--set vcomh
Write_LCD_COM(0x40);

Write_LCD_COM(0x8d);	//--set chare pump enable/disable
Write_LCD_COM(0x14);	//--set(0x10) disable
//Write_LCD_COM(0x10);	//--set(0x10) disable
Write_LCD_COM(0xaf);	//--turn on oled panel
  
          ClearLCD(0xFF);
        delay_ms(500);
        ClearLCD(0x00);
        delay_ms(500);
}

//LCD��
void OpenLCD(void)
{
  InitLCD();
}

//LCD�ر�
void CloseLCD(void)
{
  LCD_CS1;
  //LCD_BackLight1;
  //LCD_BackLight11;
  //LCD_Power1;
}

//���ͼ����ʾ
void Display_Battery_Icon(unsigned char battery_capacity)
{
  unsigned char i,j,adressd = 0;
  for(i = 0; i < 1; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    
    switch(battery_capacity)
    {
    case 0:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery0_icon[adressd]);
          adressd++;
        }
        break;
      } 
     case 1:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery1_icon[adressd]);
          adressd++;
        }
        break;
      }  
     case 2:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery2_icon[adressd]);
          adressd++;
        }
        break;
      }  
     case 3:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery3_icon[adressd]);
          adressd++;
        }
        break;
      }
     case 4:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery4_icon[adressd]);
          adressd++;
        }
        break;
      } 
     case 5:
      {
        for(j = 0; j < 16; j++)
        {
          Write_LCD_DATA(graphic_battery5_icon[adressd]);
          adressd++;
        }
        break;
      } 
    default: break;    
    }
  }
}  

//�Ÿ���ͼ����ʾ
void Display_Magnetic_Icon(unsigned char flag)
{
  unsigned char i,j,adressd = 0;
  for(i = 0; i < 1; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    if(flag)
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(graphic_magnetic_icon[adressd]);
        adressd++;
      }
    }
    else
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(0x00);//����ű���ͼ��
      }
    }
  }
}

//��V:���͡�mL����ʾ
void Display_VmL_Icon(void)
{
  unsigned char i,j,adressd = 0;
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_V_icon[adressd]);
      adressd++;
    }
  }
  adressd = 0;
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_maohao_icon[adressd]);
      adressd++;
    }
  }
  adressd = 0;
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    Write_LCD_DATA(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_m_icon[adressd]);
      adressd++;
    }
    Write_LCD_DATA(0x00);
  }
  adressd = 0;
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x09);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_L_icon[adressd]);
      adressd++;
    }
  }
}


//��TOF:���͡�Ps����ʾ
void Display_TOFPs_Icon(void)
{
  unsigned char i,j,adressd = 0;
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_T_icon[adressd]);
      adressd++;
    }
  }
  adressd = 0;
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x10);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_O_icon[adressd]);
      adressd++;
    }
  }
  adressd = 0;
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_F_icon[adressd]);
      adressd++;
    }
  }  
  adressd = 0;
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_maohao_icon[adressd]);
      adressd++;
    }
  }  
  
  adressd = 0;
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x00);
    Write_LCD_DATA(0x00);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_p_icon[adressd]);
      adressd++;
    }
    Write_LCD_DATA(0x00);
  }
  adressd = 0;
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x17);
    Write_LCD_COM(0x08);
    for(j = 0; j < 8; j++)
    {
      Write_LCD_DATA(graphic_acii_s_icon[adressd]);
      adressd++;
    }
  }
}






void Display_Switch_DateNumber(unsigned char num, unsigned char hang)
{
  unsigned char k = 0;
  switch(num)
  {
  case 0:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber0_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber0_icon[k + 8]);
      }
      break;
    }
  case 1:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber1_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber1_icon[k + 8]);
      }
      break;
    }
  case 2:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber2_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber2_icon[k + 8]);
      }
      break;
    }
  case 3:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber3_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber3_icon[k + 8]);
      }
      break;
    }
  case 4:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber4_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber4_icon[k + 8]);
      }
      break;
    }
  case 5:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber5_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber5_icon[k + 8]);
      }
      break;
    }
  case 6:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber6_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber6_icon[k + 8]);
      }
      break;
    }
   case 7:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber7_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber7_icon[k + 8]);
      }
      break;
    }
   case 8:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber8_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber8_icon[k + 8]);
      }
      break;
    }
   case 9:
    {
      for(k = 0; k < 8; k++)
      {
        if(hang == 4)
          Write_LCD_DATA(graphic_datenumber9_icon[k]);
        else if(hang == 5)
          Write_LCD_DATA(graphic_datenumber9_icon[k + 8]);
      }
      break;
    }
   default: break;   
  }
}


//�Ϸ���ͷ��ͼ����ʾ
void Display_up_Icon(unsigned char flag)
{
  unsigned char i,j,adressd = 0;
  for(i = 6; i < 8; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x08);
    if(flag)
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(graphic_up_icon[adressd]);
        adressd++;
      }
    }
    else
    {
      for(j = 0; j < 16; j++)
      {
        Write_LCD_DATA(0x00);//����Ϸ�ͼ��
      }
    }
  }
}



//�ۻ�����ʾ
void Display_Cum_Icon(unsigned long cum)
{
  unsigned char i,j;
  unsigned char dian,ge,shi,bai,qian,wan;
  cum = cum%1000000;
  wan = cum/100000;
  qian = (cum%100000)/10000;
  bai = (cum%10000)/1000;
  shi = (cum%1000)/100;
  ge = (cum%100)/10;
  dian = cum%10;
  
  //clear
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }  
  
  //wan
  if(wan)
  {
    //wan
    for(i = 1; i < 3; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x14);
      Write_LCD_COM(0x00);
      Display_Switch_DateNumber(wan,i+3);
    }
        //qian
    for(i = 1; i < 3; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x14);
      Write_LCD_COM(0x08);
      Display_Switch_DateNumber(qian,i+3);
    }
        //bai
    for(i = 1; i < 3; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x15);
      Write_LCD_COM(0x00);
      Display_Switch_DateNumber(bai,i+3);
    }
        //shi
    for(i = 1; i < 3; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x15);
      Write_LCD_COM(0x08);
      Display_Switch_DateNumber(shi,i+3);
    }
        //ge
    for(i = 1; i < 3; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x16);
      Write_LCD_COM(0x00);
      Display_Switch_DateNumber(ge,i+3);
    }
  }
  else
  {
    //qian
    if(qian)
    {
      //qian
      for(i = 1; i < 3; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x14);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(qian,i+3);
      }
          //bai
      for(i = 1; i < 3; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(bai,i+3);
      }
          //shi
      for(i = 1; i < 3; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(shi,i+3);
      }
          //ge
      for(i = 1; i < 3; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x16);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(ge,i+3);
      }
    }
    else
    {
      //bai
      if(bai)
      {
        //bai
        for(i = 1; i < 3; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(bai,i+3);
        }
                //shi
        for(i = 1; i < 3; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(shi,i+3);
        }
            //ge
        for(i = 1; i < 3; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x16);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(ge,i+3);
        }
      }
      else
      {
        //shi
        if(shi)
        {
          //shi
          for(i = 1; i < 3; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x15);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(shi,i+3);
          }
                  //ge
          for(i = 1; i < 3; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x16);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(ge,i+3);
          }
        } 
        else
        {
          //ge
          if(ge)  
          {
            //ge
            for(i = 1; i < 3; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x16);
              Write_LCD_COM(0x00);
              Display_Switch_DateNumber(ge,i+3);
            }
          }          
        }       
      }      
    }    
  }

  
  //dian
  for(i = 1; i < 3; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(dian,i+3);
  }

}


//����ʱ��
void Display_Tof_Icon(unsigned long cum)
{
  unsigned char i,j;
  unsigned char dian,ge,shi,bai,qian,wan;
  cum = cum%1000000;
  
  wan = cum/100000;
  qian = (cum%100000)/10000;
  bai = (cum%10000)/1000;
  shi = (cum%1000)/100;
  ge = (cum%100)/10;
  dian = cum%10;
  
  //clear
  /*for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x11);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }*/
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x12);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x13);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x14);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x15);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x00);
    for(j = 0; j < 16; j++)
    {
      Write_LCD_DATA(0x00);
    }
  }  
  
  //wan
  if(wan)
  {
    //wan
    for(i = 3; i < 5; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x14);
      Write_LCD_COM(0x00);
      Display_Switch_DateNumber(wan,i+1);
    }
                //qian
    for(i = 3; i < 5; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x14);
      Write_LCD_COM(0x08);
      Display_Switch_DateNumber(qian,i+1);
    }
        //bai
    for(i = 3; i < 5; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x15);
      Write_LCD_COM(0x00);
      Display_Switch_DateNumber(bai,i+1);
    }
        //shi
    for(i = 3; i < 5; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x15);
      Write_LCD_COM(0x08);
      Display_Switch_DateNumber(shi,i+1);
    }
        //ge
    for(i = 3; i < 5; i++)
    {
      LCD_CS0;
      Write_LCD_COM(0xb0 + i);
      Write_LCD_COM(0x16);
      Write_LCD_COM(0x00);
      Display_Switch_DateNumber(ge,i+1);
    }
  }
  else
  {
    //qian
    if(qian)
    {
      //qian
      for(i = 3; i < 5; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x14);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(qian,i+1);
      }
              //bai
      for(i = 3; i < 5; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(bai,i+1);
      }
          //shi
      for(i = 3; i < 5; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x15);
        Write_LCD_COM(0x08);
        Display_Switch_DateNumber(shi,i+1);
      }
          //ge
      for(i = 3; i < 5; i++)
      {
        LCD_CS0;
        Write_LCD_COM(0xb0 + i);
        Write_LCD_COM(0x16);
        Write_LCD_COM(0x00);
        Display_Switch_DateNumber(ge,i+1);
      }
    } 
    else
    {
      //bai
      if(bai)
      {
        //bai
        for(i = 3; i < 5; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(bai,i+1);
        }
                //shi
        for(i = 3; i < 5; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x15);
          Write_LCD_COM(0x08);
          Display_Switch_DateNumber(shi,i+1);
        }
            //ge
        for(i = 3; i < 5; i++)
        {
          LCD_CS0;
          Write_LCD_COM(0xb0 + i);
          Write_LCD_COM(0x16);
          Write_LCD_COM(0x00);
          Display_Switch_DateNumber(ge,i+1);
        }
      }
      else
      {
        //shi
        if(shi)
        {
          //shi
          for(i = 3; i < 5; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x15);
            Write_LCD_COM(0x08);
            Display_Switch_DateNumber(shi,i+1);
          }
                  //ge
          for(i = 3; i < 5; i++)
          {
            LCD_CS0;
            Write_LCD_COM(0xb0 + i);
            Write_LCD_COM(0x16);
            Write_LCD_COM(0x00);
            Display_Switch_DateNumber(ge,i+1);
          }
        }
        else
        {
          //ge
          if(ge)  
          {
            //ge
            for(i = 3; i < 5; i++)
            {
              LCD_CS0;
              Write_LCD_COM(0xb0 + i);
              Write_LCD_COM(0x16);
              Write_LCD_COM(0x00);
              Display_Switch_DateNumber(ge,i+1);
            }
          }          
        }        
      }      
    }   
  }
  
  //dian
  for(i = 3; i < 5; i++)
  {
    LCD_CS0;
    Write_LCD_COM(0xb0 + i);
    Write_LCD_COM(0x16);
    Write_LCD_COM(0x08);
    Display_Switch_DateNumber(dian,i+1);
  }

}


//LCDˢ��
void LCD_ReFlash(void)
{
  //�չܱ���ͼ����ʾ����
  Display_Magnetic_Icon(0);
  
  //���ʣ�����ͼ����ʾ����
  Display_Battery_Icon(g_batteryLevel);  
  
  Display_VmL_Icon();
  Display_TOFPs_Icon();
  
  //�ۻ���������ʾ����
  Display_Cum_Icon(0);
  //����ʱ��������ʾ����
  Display_Tof_Icon(0);
}


