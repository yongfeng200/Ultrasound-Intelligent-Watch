/***************************************************************************
 *
 * @file	functions.h
 * @brief	This is system functions sub header file(C17W15).
 *
 * @par		Copyright:
 *			Copyright (C) HS-WuTing 2015. All rights reserved.
 *
 * @warning -
 *
 * @par		History:
 *			- 27/07/2015    1.0
 *				- First revision.
 *
 **************************************************************************/

#ifndef FUNCTIONS_H__
#define FUNCTIONS_H__

   #define CPU           (8000000)         //��ʱ��Ϊ8Mʱ��
#define delay_us(x)   (__delay_cycles((double)x*CPU/1000000.0))
#define delay_ms(x)   (__delay_cycles((double)x*CPU/1000.0))
#define dely_s(x)     (__delay_cycles((double)x*CPU/1.0))
   
extern char startWith(unsigned char * p1,unsigned char * p2);
extern unsigned char dectoBCD(unsigned char dec);
extern unsigned char BCDtoDec(unsigned char bcd);
extern float dotHextoDotDec(unsigned long dotHex);
extern unsigned char sumCheck(unsigned char *p1, unsigned char len);


#endif	// FUNCTIONS_H__
