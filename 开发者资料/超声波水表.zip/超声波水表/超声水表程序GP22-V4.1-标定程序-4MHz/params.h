/***************************************************************************
 *
 * @file	params.h
 * @brief	This is system whole params header file(C17W15).
 *
 * @par		Copyright:
 *			Copyright (C) HS-WuTing 2015. All rights reserved.
 *
 * @warning -
 *
 * @par		History:
 *			- 15/07/2015    1.0
 *				- First revision.
 *
 **************************************************************************/

#ifndef PARAMS_H__
#define PARAMS_H__


struct tagSysPara
{
  unsigned char        szTermID[7];               /// Water meter address.
  //unsigned char        szUserID[32];              /// Water meter family code.
};
extern struct tagSysPara  g_systemPara;


/******************************************************
*The related parameters of water meter accumulation.
******************************************************/
struct tagAccumulationPara
{
  unsigned long accumulationBase;
  unsigned long accumulationPositive;
  unsigned long accumulationNegative;
  unsigned long accumulationTotal;
};
extern struct tagAccumulationPara  g_accumulationPara;


/******************************************************
*The related parameters of external trigger event.
******************************************************/
#define TRI_RTC_INTA      0x0001    /// RTC.
#define TRI_SVD           0x0002    /// SVD.

extern unsigned int g_ExternalTriggerEvent;


/******************************************************
*The related parameters of RTC.
******************************************************/
extern unsigned char g_RTCReadWriteBuffer[7];


/******************************************************
*The related parameters of SVD.
******************************************************/
extern unsigned char g_svdStartflag;
extern unsigned char g_svdLowVoltageDetectNumber;
extern unsigned char g_batteryLevel;


/******************************************************
*The related parameters of LCD.
******************************************************/
extern unsigned char g_hourDisplay;
extern unsigned char g_dayDisplay;
extern unsigned char g_monthDisplay;
extern unsigned char g_yearDisplay;
extern unsigned long g_accumulationTotalDisplay;


/******************************************************
*The related parameters of TDC.
******************************************************/
extern volatile unsigned char g_tdcInterruptFlag;
extern unsigned int  g_tdcStatusRegister;
extern unsigned long g_tdcTimeOutCount;

extern float         g_calibrateResult;
extern float         g_calibrateCorrectionFactor;

extern unsigned char g_numberOfTemperatureMeasure;
extern float         g_temperature1Result0;
extern float         g_temperature1Result1;
extern float         g_temperature1Result2;
extern float         g_temperature1Result3;
extern float         g_temperature2Result0;
extern float         g_temperature2Result1;
extern float         g_temperature2Result2;
extern float         g_temperature2Result3;
extern float         g_RhotByRref;
extern float         g_RcoldByRref;

extern float         g_timeResult0;
extern float         g_timeResult1;
extern float         g_timeResult2;
extern float         g_timeResult3;
extern float         g_averageTimeResultUp;
extern float         g_averageTimeResultDown;
extern float         g_PW1STValue;
extern long         g_timeOfFlight;
extern long         g_timeOfFlight_ave;
extern long         g_timeOfFlightBuffer[10];
extern long         g_tofDisplay;
extern float         g_waterLineSpeed;
extern float         g_waterSurfaceSpeed;
extern float         g_accumulationAmount;
extern float         g_tempAccumulationAmount;
extern unsigned char g_hitCount;
extern unsigned char g_streamCount;
extern unsigned char g_upStreamFlag;
extern unsigned char g_upTimeOutFlag;
extern unsigned char g_downTimeOutFlag;
extern unsigned char g_oneSecondAccumulationFlag;
extern unsigned char g_startAccumulationFlag;
extern unsigned char g_startAccumulationCount;
extern unsigned char g_endAccumulationCount;

extern unsigned char g_valueOpenFlag;//���ſ��ر�־
extern unsigned char g_valueOpenCount;//���ſ��ر�־


#endif  // PARAMS_H__
