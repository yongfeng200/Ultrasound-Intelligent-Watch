#include "params.h"

/***************************************************************************
 * startWith function.
 *
 * @brief	Judge the first char.
 **************************************************************************/
char startWith(unsigned char * p1,unsigned char * p2)
{
  while(*p2)
  {
    if(!*p1)
      return 0;
    if(*p1++ != *p2++)
      return 0;
  }
  return 1;
}


/***************************************************************************
 * dectoBCD function.
 *
 * @brief	Convert DEC to BCD of the char.
 **************************************************************************/
unsigned char dectoBCD(unsigned char dec)
{
   unsigned char bcd = 0;
   bcd = ((dec/10)<<4) | (dec%10);
   return bcd;
}


/***************************************************************************
 * BCDtoDec function.
 *
 * @brief	Convert BCD to DEC of the char.
 **************************************************************************/
unsigned char BCDtoDec(unsigned char bcd)
{
   unsigned char dec = 0;
   dec = ((bcd >> 4) & 0x0F)*10 + (bcd & 0x0F);
   return dec;
}


/***************************************************************************
 * DotHextoDotDec function.
 *
 * @brief	Convert Dot HEX to Dot DEC of the char.
 **************************************************************************/
float dotHextoDotDec(unsigned long dotHex)
{
   float dotDec = 0;
   dotDec = (float)(((dotHex >> 28) & 0x0000000F)*4096 + ((dotHex >> 24) & 0x0000000F)*256 + ((dotHex >> 20) & 0x0000000F)*16 + ((dotHex >> 16) & 0x0000000F)*1);
   dotDec = dotDec + ((float)((dotHex >> 12) & 0x0000000F))/16 + ((float)((dotHex >> 8) & 0x0000000F))/256 + ((float)((dotHex >> 4) & 0x0000000F))/4096 + ((float)((dotHex >> 0) & 0x0000000F))/65536;
   return dotDec;
}


/***************************************************************************
 * sumCheck function.
 *
 * @brief	Used to IR communication of sum check.
 **************************************************************************/
unsigned char sumCheck(unsigned char *p1, unsigned char len)
{
  unsigned char i, temp = 0;
  for(i = 0; i < len; i++)
  {
    temp += p1[i];
  }
  return temp;
}

