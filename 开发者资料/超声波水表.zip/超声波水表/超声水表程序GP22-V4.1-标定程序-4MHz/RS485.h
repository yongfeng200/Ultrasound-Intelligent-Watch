#ifndef RS485_H
#define RS485_H


void initRS485(void);



#endif